/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pkg20241116_4ind_campos_contalettere;
import java.util.Scanner;
/**
 *
 * @author Alexander Campos
 * 
 * il mio programma conta le lettera "A" dalla frase inserita dall'utente
 */
public class cantalettere {
    
 public void scan(){
    
     Scanner scanner = new Scanner(System.in);
     
    
     System.out.println("inserisci frase ");
     
     
     String parole = scanner.nextLine();
     
     
     int contatore =0;
     
     for(int a=0; a < parole.length(); a++){
     
         if(parole.charAt(a)=='a'){
         
          contatore++;
         }
        
     } 
         System.out.println(" numero delle lettere nella frase: " +contatore);
         
         System.out.println(" copia del numero delle lettere dentro la frase/parola ");
         
         for(int b=0; b< contatore; b++){
             System.out.println("A");
         }
         }
         
         
} 

